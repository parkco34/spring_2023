#include <iostream>
#include <string>
#include "extCreature.h"
using namespace std;

string extCreature::getSpecies()
{

}

